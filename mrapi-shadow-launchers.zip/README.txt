Copiar estos .cmd al Escritorio de Shadow.

Uso recomendado:
- Doble click en "START MRAPI W01 + RUNNER.cmd" para abrir W01 Brain y Runner juntos.
- Los otros dos sirven para arrancarlos por separado.

No modifica MRAPI DEV ni guarda credenciales.
